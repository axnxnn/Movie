function E404(){
    return (
        <div className="error-content">
            <h1>404</h1>
            <p>Page not found 😵</p>
        </div>
    )
}

export default E404;