export default {
    SITE_NAME: "Movies",
    API_URL: 'https://api.ripper.lol',
    TMDB_IMAGE_URL: 'https://image.tmdb.org/t/p',
}